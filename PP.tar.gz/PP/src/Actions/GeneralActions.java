package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import Interfaces.ContactPage;
import Interfaces.SignUpPage;

public class GeneralActions {
	SignUpPage signUpPage = new SignUpPage() {};
	ContactPage contactPage = new ContactPage() {};
	public void signUpPP(WebDriver driver, String firstName, String lastName, String email, String Password, String confirmPwd) {
		//Input data on all fields
		driver.findElement(By.xpath(signUpPage.txt_FirstName_xpath)).sendKeys(firstName);
		driver.findElement(By.xpath(signUpPage.txt_LastName_xpath)).sendKeys(lastName);
		driver.findElement(By.xpath(signUpPage.txt_EmailAddress_xpath)).sendKeys(email);
		driver.findElement(By.xpath(signUpPage.txt_Password_xpath)).sendKeys(Password);
		driver.findElement(By.xpath(signUpPage.txt_ConfirmPwd_xpath)).sendKeys(confirmPwd);
		//click submit button
		driver.findElement(By.xpath(signUpPage.txt_Submit_xpath)).click();
	}
	public void contactPP(WebDriver driver, String FirstName, String LastName, String Email, String Subject, String Message) {
		//Input data on all fields
		driver.findElement(By.xpath(ContactPage.txt_firtName_xpath)).sendKeys(FirstName);
		driver.findElement(By.xpath(ContactPage.txt_lastName_xpath)).sendKeys(LastName);
		driver.findElement(By.xpath(ContactPage.txt_email_xpath)).sendKeys(Email);
		driver.findElement(By.xpath(ContactPage.txt_subject_xpath)).sendKeys(Subject);
		driver.findElement(By.xpath(ContactPage.txt_Message_xpath)).sendKeys(Message);
		//Click button submit
		driver.findElement(By.xpath(ContactPage.txt_submit_xpath)).click();
	}
}
