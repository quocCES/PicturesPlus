package TestModules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Actions.GeneralActions;

public class TM_Contact {
	WebDriver driver;
	GeneralActions generalActios = new GeneralActions() {};
	
	@BeforeTest
  	public void beforeTest() {
		System.setProperty("webdriver.chrome.driver", "/home/code-engine-studio/Downloads/chromedriver");
		driver = new ChromeDriver();
		String baseUrl = "https://picturesplus.com/about-us/contact-us/";
		driver.get(baseUrl);
	}
	
	//TC_025 Verify that user can submit successfully when inputting valid data for all required fields
	@Test
	public void TC_025() {
		generalActios.contactPP(driver, "Test", "Ut", "ContactAuto", "I am testing", "Hi");
		String expectedMessage = "Your inquiry was submitted and will be responded to as soon as possible. Thank you for contacting us.";
		String message = driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/ul/li")).getText();
		Assert.assertEquals(expectedMessage, message);
	}
	
	@AfterTest
	public void afterTest() {
		driver.quit();
	}
}
